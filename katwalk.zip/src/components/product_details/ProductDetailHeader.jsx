import React from 'react'

const ProductDetailHeader = () => {
    return (
        <div className="product_detail_header">
                <h4>Aliya Designs</h4>
                <h6>Simple Elegant Abaya</h6>
            </div>
    )
}

export default ProductDetailHeader
