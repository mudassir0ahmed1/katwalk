import React from 'react'
import CardGrids from './GridCards'

const WhatsNew = () => {
    return (
        <CardGrids heading="What's new in designers" viewMore  gridStyleThree/>
    )
}

export default WhatsNew
