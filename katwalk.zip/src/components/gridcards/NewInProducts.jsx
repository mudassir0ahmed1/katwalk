import React from 'react'
import CardGrids from './GridCards'

const NewInProducts = () => {
    return (
           <CardGrids heading='What’s new in Products?'/>
        
    )
}

export default NewInProducts
