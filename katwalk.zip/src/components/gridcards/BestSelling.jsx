import React from 'react'
import CardGrids from './GridCards'

const BestSelling = () => {
    return (
        <CardGrids heading='Best Selling in Katwalk' gridStyleThree/>
    )
}

export default BestSelling
